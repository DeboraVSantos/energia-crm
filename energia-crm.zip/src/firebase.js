
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyCHXoTwNonlZCMEssSAfE91jAaQ9OU7cTM",
  authDomain: "energia-crm.firebaseapp.com",
  projectId: "energia-crm",
  storageBucket: "energia-crm.appspot.com",
  messagingSenderId: "444201214229",
  appId: "1:444201214229:web:2cab5511d615a75091091c",
  measurementId: "G-65974QTGXP"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const storage = getStorage(app);

export { db, storage };
