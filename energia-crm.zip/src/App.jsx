
import { useState } from "react";
import { db, storage } from "./firebase";
import { collection, addDoc } from "firebase/firestore";
import { ref, uploadBytes } from "firebase/storage";

export default function App() {
  const [form, setForm] = useState({
    nome: "",
    nif: "",
    telefone: "",
    vendedor: "",
    feedback: "",
    documentos: []
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleFileChange = (e) => {
    setForm({ ...form, documentos: Array.from(e.target.files) });
  };

  const salvar = async () => {
    const docRef = await addDoc(collection(db, "clientes"), {
      nome: form.nome,
      nif: form.nif,
      telefone: form.telefone,
      vendedor: form.vendedor,
      feedback: form.feedback
    });

    for (const file of form.documentos) {
      const storageRef = ref(storage, `documentos/${docRef.id}/${file.name}`);
      await uploadBytes(storageRef, file);
    }

    alert("Cliente salvo!");
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Energia CRM</h2>
      <input placeholder="Nome" name="nome" onChange={handleChange} />
      <input placeholder="NIF" name="nif" onChange={handleChange} />
      <input placeholder="Telefone" name="telefone" onChange={handleChange} />
      <input placeholder="Vendedor" name="vendedor" onChange={handleChange} />
      <textarea placeholder="Feedback" name="feedback" onChange={handleChange}></textarea>
      <input type="file" multiple onChange={handleFileChange} />
      <button onClick={salvar}>Salvar Cliente</button>
    </div>
  );
}
